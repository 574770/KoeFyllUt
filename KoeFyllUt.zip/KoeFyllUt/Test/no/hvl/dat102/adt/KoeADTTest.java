package no.hvl.dat102.adt;

import no.hvl.dat102.exception.EmptyCollectionException;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public abstract class KoeADTTest {
	private KoeADT<Integer> koe;

	// Testdata
	private Integer e0 = 1;
	private Integer e1 = 2;
	private Integer e2 = 3;
	private Integer e3 = 4;
	private Integer e4 = 5;

	protected abstract KoeADT<Integer> reset();

	/*
	 * Henter en ny stabel for hver test
	 * 
	 * @return
	 */

	@BeforeEach
	public void setup() {
		koe = reset();

	}
	
	@Test
	public void erTom() {
		assertTrue(koe.erTom());
		
	}

	@Test
	public void InnKoe() {
		koe.innKoe(e0);
		assertEquals (1, koe.antall());
		
		koe.innKoe(e1);
		assertEquals(2, koe.antall());
		
		koe.innKoe(e2);
		assertEquals(3, koe.antall());
		
		koe.innKoe(e3);
		assertEquals(4, koe.antall());
		
		koe.innKoe(e4);
		assertEquals(5, koe.antall());
		
		
		
	}
	
	@Test
	public void TestAntall() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e2);
		koe.innKoe(e3);
		koe.innKoe(e4);
		
		koe.utKoe();
		assertEquals(4, koe.antall());
	}
	
	@Test
	public void TestFoereste() {
		koe.innKoe(e1);
		koe.utKoe();
		koe.innKoe(e2);
		koe.innKoe(e3);
		koe.innKoe(e4);
		koe.utKoe();
		
		assertEquals(4, koe.foerste());
	}
	
	@Test
	public void TestUtKoeOgSlett() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e2);
		koe.innKoe(e3);
		
		assertEquals(e0, koe.utKoe());
		assertEquals(3, koe.antall());
		assertEquals(e1, koe.utKoe());
		assertEquals(2, koe.antall());
		assertEquals(e2, koe.utKoe());
		assertEquals(1, koe.antall());
		assertEquals(e3, koe.utKoe());
		assertEquals(0, koe.antall());
		assertTrue(koe.erTom());
		
	}
	
	@Test
	public void InnOgUtMedDuplikater() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e1);
		koe.innKoe(e2);
		
		assertEquals(e0, koe.utKoe());
		assertEquals(e1,koe.utKoe());
		assertEquals(e1, koe.utKoe());
		assertEquals(e2, koe.utKoe());
	}
	
	//Test toString
	@Test
	public void popFromEmptyIsUnderflowed() {
		/*
		 * Assertions.assertThrows(EmptyCollectionException.class, new Executable() {
		 * 
		 * @Override public void execute() throws Throwable { stabel.pop(); } });
		 */

		Assertions.assertThrows(EmptyCollectionException.class, () -> {
			koe.utKoe();
		});
	}
}
	
	

		


