package no.dat102.kjedet;

import no.hvl.dat102.adt.KoeADT;
import no.hvl.dat102.kjedet.KjedetKoe;

public abstract class KjedetKoeTest {

	protected KoeADT<Integer> reset() {
		return new KjedetKoe<Integer>();
	}

}
